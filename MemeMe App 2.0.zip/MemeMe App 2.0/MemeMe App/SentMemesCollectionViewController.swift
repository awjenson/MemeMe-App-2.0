//
//  SentMemesCollectionViewController.swift
//  MemeMe App
//
//  Created by Andrew Jenson on 8/9/17.
//  Copyright © 2017 Andrew Jenson. All rights reserved.
//

import UIKit

class SentMemesCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var flowLayout: UICollectionViewFlowLayout!
    
    var memes: [Meme]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        memes = appDelegate.memes
        
        let space:CGFloat = 3.0
        // to access the size of the main view, use self.view.frame.size
        // here we are accessing the size of the width property and can do the same for height
        let dimensionWidth = (view.frame.size.width - (2 * space)) / 3.0
        let dimensionHeight = (view.frame.size.height - (2 * space)) / 3.0
        
        flowLayout.minimumInteritemSpacing = space
        // minimum spacing between rows
        flowLayout.minimumLineSpacing = space
        // size of the cells which is dependent on the size of the main view, 
        // which is dependent upon screen size
        flowLayout.itemSize = CGSize(width: dimensionWidth, height: dimensionHeight)
        
    }
    
    // MARK: Collection View Data Source
    
    // The 3 essential methods implemented for a Collection View
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        // return the number of memes in the memes array
        return memes.count
    }

    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        // write a custom cell
        // add a Cocoa Touch Class to your project and have it inherit from UICollectionViewCell
        
        //  you’ll dequeue an instance of your cell class and populate it with data.
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CustomMemeCell", for: indexPath) as! CustomMemeCell
        let villain = self.memes[(indexPath as NSIndexPath).row]
        
        // Set the name and image
//        cell.topLabel.text = villain.name
//        cell.bottomLabel.text = villain.name
//        cell.villainImageView?.image = UIImage(named: villain.imageName)
        
        return cell
        
        // return a custom cell
    }
    
    
//    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        // should present a detail view of the selected meme
//        // grab an instance of your detailViewController from the storyboard, populate the detailViewController 
//        // with the appropriate meme, and present it using navigation
//        
//        // Grab the DetailVC from Storyboard
//        let detailController = self.storyboard!.instantiateViewController(withIdentifier: "VillainDetailViewController") as! VillainDetailViewController
//        
//        //Populate view controller with data from the selected item
//        detailController.villain = allVillains[(indexPath as NSIndexPath).row]
//        
//        // Present the view controller using navigation
//        navigationController!.pushViewController(detailController, animated: true
//        
//    }

    
           
}
