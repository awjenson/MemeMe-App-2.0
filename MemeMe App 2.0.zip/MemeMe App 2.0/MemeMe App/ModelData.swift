//
//  ModelData.swift
//  MemeMe App
//
//  Created by Andrew Jenson on 8/2/17.
//  Copyright © 2017 Andrew Jenson. All rights reserved.
//

import UIKit


// Meme(topText: topTextField.text!, bottomText: bottomTextField.text!, originalImage: imageView.image!, memedImage: memedImage)
struct Meme {
    
  // properites
  var topText: String
  var bottomText: String
  var originalImage: UIImage
  var memedImage: UIImage
  
  // init is not required, as the struct has implemented the default init method
  // with all declared properties
}
