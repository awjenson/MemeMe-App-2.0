//
//  CustomMemeCell.swift
//  MemeMe App
//
//  Created by Andrew Jenson on 8/9/17.
//  Copyright © 2017 Andrew Jenson. All rights reserved.
//

import UIKit

class CustomMemeCell: UICollectionViewCell {
    
    // MARK: Outlets
    
    // give your custom cell the properties you need to display a meme
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var topLabel: UILabel!
    @IBOutlet weak var bottomLabel: UILabel!

    
}
