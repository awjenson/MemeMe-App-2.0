//
//  MemeMeEditorVC.swift
//  MemeMe App
//
//  Created by Andrew Jenson on 7/28/17.
//  Copyright © 2017 Andrew Jenson. All rights reserved.
//

import UIKit

// MARK: - UIViewController
class MemeMeEditorVC: UIViewController {

  // MARK: - Outlets

  @IBOutlet weak var imagePickerView: UIImageView!
  @IBOutlet weak var topTextField: UITextField!
  @IBOutlet weak var navigationBar: UINavigationBar!
  @IBOutlet weak var toolbar: UIToolbar!
  @IBOutlet weak var bottomTextField: UITextField!
  @IBOutlet weak var shareButton: UIBarButtonItem!
  @IBOutlet weak var cancelButton: UIBarButtonItem!
  @IBOutlet weak var cameraButton: UIBarButtonItem!
  @IBOutlet weak var albumButton: UIBarButtonItem!

  // MARK: - Properties

  let memeTextAttributes = [
      NSStrokeColorAttributeName : UIColor.black,
      NSForegroundColorAttributeName : UIColor.white,
      NSFontAttributeName : UIFont(name: "Impact", size: 30)!,
      NSStrokeWidthAttributeName : -3.0
      ] as [String : Any]

  var originalImage: UIImage?
  var memedImage: UIImage?

  // MARK: - Lifecycle Methods
  
  override func viewDidLoad() {
      super.viewDidLoad()
      // display top and bottom text fields with meme font style and delegate

      configureTextField(textFieldIBOutlet: topTextField, intialDisplayTextAllCaps: "TOP")
      configureTextField(textFieldIBOutlet: bottomTextField, intialDisplayTextAllCaps: "BOTTOM")
  }

  func configureTextField(textFieldIBOutlet: UITextField, intialDisplayTextAllCaps: String) {
      // configure textField here
      textFieldIBOutlet.text = intialDisplayTextAllCaps
      textFieldIBOutlet.defaultTextAttributes = memeTextAttributes
      textFieldIBOutlet.textAlignment = .center
      textFieldIBOutlet.autocapitalizationType = UITextAutocapitalizationType.allCharacters
      // assign delegate to the text fields
      textFieldIBOutlet.delegate = self
  }

  override func viewWillAppear(_ animated: Bool) {
      super.viewWillAppear(animated)
      
      // check if image has been selected.  Share button is not enabled until the user selects an image
      if imagePickerView.image == nil {
          shareButton.isEnabled = false
      } else {
          shareButton.isEnabled = true
      }
      
      // disable the camera button in cases when this bool returns false for the camera sourceType
      cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
      
      subscribeToKeyboardNotifications()
  }

  override func viewDidDisappear(_ animated: Bool) {
      super.viewWillDisappear(animated)
      
      unsubscribeFromKeyboardNotifications()
  }

  // MARK: - TextField Methods

  func setupInitialTextDisplayWithDelegate(_ selectedIBOutlet: UITextField) {
      selectedIBOutlet.defaultTextAttributes = memeTextAttributes
      selectedIBOutlet.textAlignment = .center
      selectedIBOutlet.autocapitalizationType = UITextAutocapitalizationType.allCharacters
      // assign delegate to the text fields
      selectedIBOutlet.delegate = self
  }

  // MARK: - Camera, Photo Library, Saved Photo Albums Button Methods
  
  func accessUIImageController(withACase: UIImagePickerControllerSourceType) {
      
      let imagePicker = UIImagePickerController()
      imagePicker.delegate = self
      imagePicker.sourceType = withACase
      present(imagePicker, animated: true, completion: nil)
  }

  // MARK: - Keyboard Methods

  func getKeyboardHeight(_ notification:Notification) -> CGFloat {
      
      // Notifications carry info in the userInfo dictionary
      let userInfo = notification.userInfo
      
      // the UIKeyboardWillShowNotification carries the keyboard frame in its userInfo dictionary
      let keyboardSize = userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue // of CGRect
      return keyboardSize.cgRectValue.height
  }

  func keyboardWillShow(_ notification:Notification) {
      // when we shift the keyboard, we always want to set it the negative amount of the keyboard height
      
      // this shifts the view so that the keyboard does not overlay the text field
      //Notifications provide a way to annouce info throughout a program across classes
      // to annouce info like the keyboard appearing/disappearing
      
      // use the frame property to shift the main view up in order to not have text covered by keyboard
      // the point where y = 0 is at the top of the frame
      // to move the view up above the keyboard, we subtract the height of the keyboard
      
      // we only want to have the keyboard move for the bottom textField
      if bottomTextField.isFirstResponder {
          self.view.frame.origin.y =  getKeyboardHeight(notification) * -1
      }
  }

  // move the view back down when the keyboard is dismissed
  func keyboardWillHide(_ notification:Notification) {
      // When we hide the keyboard, we always want the origin to be at the original position which is at 0
      // this shifts the view so that the keyboard does not overlay the text field
      //Notifications provide a way to annouce info throughout a program across classes
      // to annouce info like the keyboard appearing/disappearing
      
      // to place the view use the frame property to shift the main view up
      // the point where y = 0 is at the top of the frame
      // to move the view up above the keyboard, we subtract the height of the keyboard
      
      // we only want to have the keyboard move for the bottom textField
      if bottomTextField.isFirstResponder {
          view.frame.origin.y = 0
      }
  }

  func subscribeToKeyboardNotifications() {
      
      //the view controller is signing up to be notified when an event is coming up
      //the "event", .UIKeyboardWillShow
      // tells the VC that the keyboard is going to shift up
      
      // subscribeFromKeyboardNotification uses addObserver
      NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
      NotificationCenter.default.addObserver(self, selector: #selector(MemeMeEditorVC.keyboardWillHide(_:))    , name: NSNotification.Name.UIKeyboardWillHide, object: nil)
      
      // this func gets called above in viewWillAppear
  }

  func unsubscribeFromKeyboardNotifications() {
      // finally, we need to unsubscribe from keyboard notifications
      
      // unsubscribeFromKeyboardNotification uses removeObserver
      NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
      NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
      // this func gets called in viewWillDisappear
  }

  // MARK: - Initializing a Meme object

  // create a UIImage that combines the imageView and two textFields
  func generateMemedImage() -> UIImage {
    // Hide navbar and toolbar so they don't display when you generate MemedImage
    navigationBarAndToolbarIsHidden(decision: true)
    
    // Render view to an image
    UIGraphicsBeginImageContext(self.view.frame.size)
    view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
    let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
    UIGraphicsEndImageContext()
    
    // re-display navbar and toolbar after image is rendered
    navigationBarAndToolbarIsHidden(decision: false)
    
    return memedImage
  }

  func navigationBarAndToolbarIsHidden(decision: Bool) {
    navigationBar.isHidden = decision
    toolbar.isHidden = decision
  }

  func saveMeme() {
    // Create the meme
    let memedImage = generateMemedImage()
    
    // memedImage is the edited image of the original image combined with the overlayed text
    // Meme is a Struct Type
    // originalImage references the IBOutlet imagePickerView
    let meme = Meme(topText: topTextField.text!, bottomText: bottomTextField.text!, originalImage: imagePickerView.image!, memedImage: memedImage)
    
    // add it to the memes array on the Application Delegate
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    appDelegate.memes.append(meme)
  }

  // MARK: - Actions

  // pick an image from album
  @IBAction func albumButtonTapped(_ sender: Any) {
    // call from Camera, Photo Library, Saved Photo Albums Button Methods
    accessUIImageController(withACase: .photoLibrary)
  }

  @IBAction func cameraButtonTapped(_ sender: Any) {
    // call from Camera, Photo Library, Saved Photo Albums Button Methods
    accessUIImageController(withACase: .camera)
  }

  @IBAction func cancelButtonTapped(_ sender: Any) {
    // reset the text fields to default text
    topTextField.text = "TOP"
    bottomTextField.text = "BOTTOM"
    imagePickerView.image = nil
    shareButton.isEnabled = false
  }

  // button tapped to activate activityViewController to allow user to share photos
  @IBAction func shareButtonTapped(_ sender: Any) {
    // generate a memedImage
    let memedImage = generateMemedImage()
    
    // define an instance of the ActivityViewController
    // You need to implement an Activity View Controller linked to the share button
    let activityVC = UIActivityViewController(activityItems: [memedImage], applicationActivities: nil)
    
    // pass the ActivityViewController a memedImage as an activity item
    // Once you have the Activity View Controller set up you can call your saveMeme function from there.
    activityVC.completionWithItemsHandler = { activity, success, items, error in
        self.saveMeme()
        self.dismiss(animated: true, completion: nil)
    }
    
    // present the ActivityViewController
    present(activityVC, animated: true, completion: nil)
  }
}

// MARK: - UITextFieldDelegate
extension MemeMeEditorVC: UITextFieldDelegate {
  
  // When a user presses return, the keyboard should be dismissed
  // textFieldShouldReturn + resignFirstResponder + return true: dismisses the keyboard when the user clicks the Return button
  func textFieldDidBeginEditing(_ textField: UITextField) {
    if (textField == topTextField && textField.text! == "TOP") || (textField == bottomTextField && textField.text! == "BOTTOM") {
      textField.text = ""
    }
  }
  
  func textFieldShouldReturn(_ textField: UITextField) -> Bool {
    textField.resignFirstResponder()
    
    return true;
  }
}

// MARK: - UIImagePickerControllerDelegate and UINavigationControllerDelegate
extension MemeMeEditorVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
  
  // UIImagePickerController inherits from UINavigationController.
  // The delegate property is part of UINavigationController, so it requires that 
  // its delegate conforms to the UINavigationControllerDelegate protocol
  
  // Tells the delegate that the user picked a still image or movie.
  func imagePickerController(_ picker: UIImagePickerController,
                             didFinishPickingMediaWithInfo info: [String : Any]) {
    
    if let image = info[UIImagePickerControllerOriginalImage] as? UIImage {
      imagePickerView.image = image
    }
    dismiss(animated: true, completion: nil)
  }
  
  // Tells the delegate that the user cancelled the pick operation.
  func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
    
    dismiss(animated: true, completion: nil)
  }
}
